﻿namespace CadastroProdutos
{
    partial class Cadastro_produto
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_Cadastrar = new Button();
            txt_nome = new TextBox();
            cmb_filtros = new ComboBox();
            dataGridView1 = new DataGridView();
            txtPreco = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            cmb_categoria = new ComboBox();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // btn_Cadastrar
            // 
            btn_Cadastrar.Location = new Point(25, 22);
            btn_Cadastrar.Name = "btn_Cadastrar";
            btn_Cadastrar.Size = new Size(88, 36);
            btn_Cadastrar.TabIndex = 0;
            btn_Cadastrar.Text = "Cadastrar";
            btn_Cadastrar.UseVisualStyleBackColor = true;
            btn_Cadastrar.Click += btn_Cadastrar_Click;
            // 
            // txt_nome
            // 
            txt_nome.Location = new Point(209, 22);
            txt_nome.Name = "txt_nome";
            txt_nome.Size = new Size(165, 23);
            txt_nome.TabIndex = 1;
            txt_nome.TextChanged += txt_nome_TextChanged;
            // 
            // cmb_filtros
            // 
            cmb_filtros.FormattingEnabled = true;
            cmb_filtros.Location = new Point(25, 221);
            cmb_filtros.Name = "cmb_filtros";
            cmb_filtros.Size = new Size(121, 23);
            cmb_filtros.TabIndex = 4;
            cmb_filtros.Text = "Categorias ";
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(25, 263);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.CellSelect;
            dataGridView1.Size = new Size(430, 150);
            dataGridView1.TabIndex = 5;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // txtPreco
            // 
            txtPreco.Location = new Point(209, 80);
            txtPreco.Name = "txtPreco";
            txtPreco.Size = new Size(165, 23);
            txtPreco.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(150, 25);
            label1.Name = "label1";
            label1.Size = new Size(40, 15);
            label1.TabIndex = 7;
            label1.Text = "Nome";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(150, 54);
            label2.Name = "label2";
            label2.Size = new Size(58, 15);
            label2.TabIndex = 8;
            label2.Text = "Categoria";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(150, 83);
            label3.Name = "label3";
            label3.Size = new Size(37, 15);
            label3.TabIndex = 9;
            label3.Text = "Preço";
            // 
            // cmb_categoria
            // 
            cmb_categoria.FormattingEnabled = true;
            cmb_categoria.Location = new Point(209, 51);
            cmb_categoria.Name = "cmb_categoria";
            cmb_categoria.Size = new Size(165, 23);
            cmb_categoria.TabIndex = 10;
            // 
            // button1
            // 
            button1.Location = new Point(199, 220);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 11;
            button1.Text = "Pesquisar ";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Cadastro_produto
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(cmb_categoria);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtPreco);
            Controls.Add(dataGridView1);
            Controls.Add(cmb_filtros);
            Controls.Add(txt_nome);
            Controls.Add(btn_Cadastrar);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Cadastro_produto";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "CadastroProdutos";
            Load += Cadastro_produto_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn_Cadastrar;
        private TextBox txt_nome;
        private ComboBox cmb_filtros;
        private DataGridView dataGridView1;
        private TextBox txtPreco;
        private Label label1;
        private Label label2;
        private Label label3;
        private ComboBox cmb_categoria;
        private Button button1;
    }
}
