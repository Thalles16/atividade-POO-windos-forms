using System;

namespace CadastroProdutos
{
    public partial class Cadastro_produto : Form
    {

        public Cadastro_produto()
        {
            InitializeComponent();

        }

        private void txt_nome_TextChanged(object sender, EventArgs e)
        {


        }

        private List<Produto> listaProdutos = new List<Produto>();

        private void btn_Cadastrar_Click(object sender, EventArgs e)
        {

            try
            {

                if (string.IsNullOrWhiteSpace(txt_nome.Text))
                {
                    MessageBox.Show("Por favor, preencha o nome do produto.");
                    return;
                }

                if (cmb_categoria.SelectedItem == null)
                {
                    MessageBox.Show("Por favor, selecione uma categoria.");
                    return;
                }

                if (!decimal.TryParse(txtPreco.Text, out decimal preco))
                {
                    MessageBox.Show("Pre�o inv�lido. Digite um n�mero v�lido.");
                    return;
                }

                string nome = txt_nome.Text;
                string categoria = cmb_categoria.SelectedItem.ToString();


                Produto novoProduto = new Produto(nome, categoria, preco);


                listaProdutos.Add(novoProduto);
                dataGridView1.Rows.Add(novoProduto.Nome, novoProduto.Preco.ToString("C"), novoProduto.Categoria);

                MessageBox.Show("Produto cadastrado com sucesso!");


            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro inesperado: " + ex.Message);
            }



        }

        private void Cadastro_produto_Load(object sender, EventArgs e)
        {
            cmb_categoria.Items.Add("Bebidas");
            cmb_categoria.Items.Add("Farin�ceos");
            cmb_categoria.Items.Add("Hortifruti");
            cmb_categoria.Items.Add("Limpeza");
            cmb_categoria.Items.Add("Congelados");

            cmb_filtros.Items.Add("Bebidas");
            cmb_filtros.Items.Add("Farin�ceos");
            cmb_filtros.Items.Add("Hortifruti");
            cmb_filtros.Items.Add("Limpeza");
            cmb_filtros.Items.Add("Congelados");

            // Configura o DataGridView com 3 colunas
            dataGridView1.ColumnCount = 3;
            dataGridView1.Columns[0].Name = "Nome";
            dataGridView1.Columns[1].Name = "Pre�o";
            dataGridView1.Columns[2].Name = "Categoria";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (cmb_filtros.SelectedItem == null)
            {
                MessageBox.Show("Por favor, selecione uma categoria para filtrar.");
                return;
            }

            string categoriaSelecionada = cmb_filtros.SelectedItem.ToString();

            // Limpa o DataGridView antes de mostrar os resultados filtrados
            dataGridView1.Rows.Clear();

            // Mostra apenas os produtos da categoria selecionada
            foreach (Produto produto in listaProdutos)
            {
                if (produto.Categoria == categoriaSelecionada)
                {
                    dataGridView1.Rows.Add(produto.Nome, produto.Preco.ToString("C"), produto.Categoria);
                }
            }
        }
    }
}
